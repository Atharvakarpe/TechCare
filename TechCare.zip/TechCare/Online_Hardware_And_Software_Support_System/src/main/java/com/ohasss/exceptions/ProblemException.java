package com.ohasss.exceptions;

public class ProblemException extends Exception {
	
	public ProblemException() {
		// TODO Auto-generated constructor stub
	}
	
	public ProblemException(String message) {
		super(message);
	}

}
